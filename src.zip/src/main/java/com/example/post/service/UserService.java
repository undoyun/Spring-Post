package com.example.post.service;

import java.util.List;
import java.util.NoSuchElementException;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.post.model.users.User;
import com.example.post.repository.UserRepository;

@Service

public class UserService {
   /*
    * 의존성 주입 방법
    * 1. 필드 주입
    * 2. 생성자 주입
    * 3. 세터 주입
    *
    * Spring Data Jpa의 CRUD
    * Create : save(엔티티 객체)
    * Read : findById(객체의 id), findAll(), findByUsername(객체의 username)
    * Update : 없음(영속성 컨텍스트에서 변경 감지를 통해 업데이트)
    * Delete : deleteById(id)
    */

   @Autowired
   private UserRepository userRepository;

   // 생성자 주입
   public UserService(UserRepository userRepository) {
      this.userRepository = userRepository;
   }

   @Autowired
   public void setUserRepository(UserRepository userRepository) {
      this.userRepository = userRepository;
   }

   // 필드 주입 방법
   // 사용자 등록
   public User registerUser(User user) {
      return userRepository.save(user);
   }

   // ID로 사용자 조회
   public User findById(Long id) {
      // 서비스 레이어를 통해 ID로 사용자 조회
      Optional<User> result = userRepository.findById(id);

      if (result.isPresent()) {
         return result.get(); // 사용자 정보가 없으면 에러 페이지로 이동
      }

      throw new RuntimeException("회원정보가 없습니다.");
   }

   // public List<User> findAll() {
   // List<User> result = userRepository.findAll();
   //
   // List<User> userList = new ArrayList<>();
   //
   // for (User user : result) {
   // userList.add(user);
   // }
   //
   // return userList;
   // }

   public List<User> findAll() {
      return userRepository.findAll();
   }

   // ID로 사용자 삭제
   public User removeId(Long id) {
      Optional<User> findUser = userRepository.findById(id);
      if (findUser.isPresent()) {
         User user = findUser.get();
         userRepository.delete(user);
         return user; // 삭제된 사용자 반환
      }
      throw new RuntimeException("사용자를 찾을 수 없습니다."); // 사용자가 없는 경우 예외 처리
   }

   // username으로 회원정보 조회
   public User getUserbyUsername(String username) {
      User user = userRepository.findByUsername(username);
      if (user == null) {
         throw new NoSuchElementException("사용자가 존재하지 않습니다.");
      }
      return user;
   }

}
