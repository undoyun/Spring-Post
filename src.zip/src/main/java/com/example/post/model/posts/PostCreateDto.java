package com.example.post.model.posts;

import java.time.LocalDateTime;

import com.example.post.model.users.User;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class PostCreateDto {

    @NotBlank(message = "제목은 필수입니다.")
    @Size(min = 2, max = 200, message = "제목은 2자 이상 200자 이하이어야 합니다.")
    private String title;            // 제목


    @NotBlank(message = "내용은 필수입니다.")
    @Size(min = 1, message = "내용은 1자 이상이어야 합니다.")
    private String content;            // 내용(VARCHAR 255)


    private User user;               // 작성자
    private int views;               // 조회수
    private LocalDateTime createTime;   // 작성일

    // 조회수 증가
    public void incrementViews() {

        this.views++;
    }

    public Post toEntity() {
        return Post.builder()
                .title(this.title)
                .content(this.content)
                .user(this.user)
                .views(this.views)
                .createTime(this.createTime)
                .build();

    }
}
