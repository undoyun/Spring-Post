package com.example.post.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import lombok.extern.slf4j.Slf4j;

// 홈 컨트롤러는 메인 화면을 보여주는 컨트롤러
// 메인 화면은 모든 사용자가 접근할 수 있는 화면
// 로그인 하지 않은 사용자도 접근할 수 있는 화면
@Slf4j
@Controller
public class HomeController {

	@GetMapping("/")
	public String home() {
		log.info("home controller");
		// throw new RuntimeException("테스트 예외");
		return "index";
	}
}
