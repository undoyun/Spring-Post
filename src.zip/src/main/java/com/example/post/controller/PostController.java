package com.example.post.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.SessionAttribute;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.multipart.MultipartFile;

import com.example.post.model.posts.Post;
import com.example.post.model.posts.PostCreateDto;
import com.example.post.model.posts.PostUpdateDto;
import com.example.post.model.users.User;
import com.example.post.service.PostService;

import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RequiredArgsConstructor
@Controller
public class PostController {
   private final PostService postService;

   // 게시글 작성
   @GetMapping("posts/create")
   public String createPostForm(
         // 세션에 저장된 데이터를 조회한다.
         @SessionAttribute(name = "loginUser", required = false) User loginUser,
         @ModelAttribute PostCreateDto postCreateDto) {
      // 사용자가 로그인을 했는지 체크
      log.info("loginUser: {}", loginUser);

      // if(loginUser == null) {
      // // 로그인 유저가 없어서 redirect 됬다는 것은 처음 사용자가 요처한 정보가 다시 요청됬으므로 이전 요청은 삭제되고 다시 요청이
      // 된것음
      // // 로그인을 하지 않았으면 로그인 페이지로 리다이렉트
      // return "redirect:/users/login";
      // }

      // 게시글 작성 페이지에 뷰 이름을 리턴
      return "posts/create";
   }

   // 게시글 등록
   @PostMapping("posts")
   public String savePost(
         @Validated @ModelAttribute PostCreateDto postCreateDto,
         BindingResult bindingResult,
         @SessionAttribute(name = "loginUser") User loginUser,
         @RequestParam(name = "file", required = false) MultipartFile file) {

      // log.info("post:{}", postCreateDto);

      try {
         log.info("file.getOriginalFilename(): {}", file.getOriginalFilename());
         log.info("file.getSize(): {}", file.getSize());
         String uploadDir = "/Users/yun-undo/Desktop/workspace/file";
         file.transferTo(new File(uploadDir+ file.getOriginalFilename()));
         log.info("file 저장 성공");
      } catch (IllegalStateException | IOException e) {
         log.info("file 저장 실패");
      }


      // 유효성 검증이 실패 했는지 확인
      if (bindingResult.hasErrors()) {
         log.info("유효성 검즘 실패");
         return "posts/create";
      }

      // 세션에서 사용자 정보를 가져와서 Post 객체에 넣어준다
      Post post = postCreateDto.toEntity();
      post.setUser(loginUser);
      Post savedPost = postService.savePost(post);
      log.info("savedPost: {}", savedPost);
      return "redirect:/posts";
   }
   // -----------------------------------------------------------------------------------------
   // //

   // 게시글 목록 조회
   @GetMapping("posts")
   public String listPosts(
         @SessionAttribute(name = "loginUser", required = false) User loginUser,
         Model model) {
      // if(loginUser==null) {
      // return "redirect:/users/login";
      // }

      List<Post> Posts = postService.getAllPosts();
      model.addAttribute("posts", Posts);
      return "posts/list";
   }
   // -----------------------------------------------------------------------------------------
   // //

   // 게시글 조회
   @GetMapping("posts/{postId}")
   public String viewPosts(@PathVariable(name = "postId") Long postId,
         Model model) {
      Post findPost = postService.getPostById(postId);
      model.addAttribute("post", findPost);
      return "posts/view";
   }
   // -----------------------------------------------------------------------------------------
   // //

   // 게시글 삭제
   @GetMapping("/posts/remove/{postId}")
   public String removePost(
         @SessionAttribute(name = "loginUser") User loginUser,
         @PathVariable(name = "postId") Long postId) {

      // 삭제하려고 하는 게시글이 로그인 사용자가 작성한 글인지 확인
      Post findPost = postService.getPostById(postId);
      // 로그인 사용자와 작성자가 다르면 삭제하지 않고 목록 페이지로 리다이렉트한다.
      if (findPost == null || findPost.getUser().getId() != loginUser.getId()) {
         return "redirect:/posts";
      }

      postService.removePost(postId);

      return "redirect:/posts";

   }
   // -----------------------------------------------------------------------------------------

   // 게시글 수정
   @GetMapping("posts/edit/{postId}")
   public String editPostForm(
         @PathVariable(name = "postId") Long postId,
         @SessionAttribute(name = "loginUser") User loginUser,
         Model model) {
      Post findPost = postService.getPostById(postId);

      // 본인 글만 수정 가능
      if (findPost == null || !findPost.getUser().getId().equals(loginUser.getId())) {
         return "redirect:/posts"; // 게시글이 없거나 본인이 작성한 글이 아닐 경우 목록으로 리다이렉트
      }

      // PostUpdateDto에 기존 게시글의 내용을 설정
      PostUpdateDto postUpdateDto = PostUpdateDto.fromEntity(findPost);
      model.addAttribute("postUpdateDto", postUpdateDto);
      model.addAttribute("post", findPost);
      return "posts/edit";
   }

   // 게시글 수정 처리하기
   @PostMapping("posts/{postId}")
   public String updatePost(
         @PathVariable(name = "postId") Long postId,
         @SessionAttribute(name = "loginUser") User loginUser,
         @ModelAttribute PostUpdateDto postUpdateDto,
         BindingResult bindingResult,
         Model model) {
      Post findPost = postService.getPostById(postId);

      // 유효성 검증이 실패 했는지 확인
      if (bindingResult.hasErrors()) {
         log.info("유효성 검증 실패");
         return "posts/edit";
      }

      if (findPost == null || !findPost.getUser().getId().equals(loginUser.getId())) {
         return "redirect:/posts";
      }

      Post updatedPost = postUpdateDto.toEntity();

      // 수정된 게시글의 조회수를 0으로 초기화하려면
      updatedPost.setViews(0);
      postService.updatePost(postId, updatedPost);
      return "redirect:/posts";
   }

}