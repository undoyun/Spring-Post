package com.example.post.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.post.model.posts.Post;

public interface PostRepository extends JpaRepository<Post, Long> {
    // Post getPostById(String postId);
}
